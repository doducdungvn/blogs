# Astro + Decap CMS Blog

Mẫu blog dùng Astro + Decap CMS, deploy trên GitHub Pages. Viết bài bằng Markdown hoặc qua giao diện quản trị `/admin/`.