---
title: "Bài viết mẫu đầu tiên"
slug: "bai-viet-mau"
date: 2025-06-19
tags: ["astro", "decap"]
cover_image: "/cover.jpg"
excerpt: "Đây là bài viết mẫu đầu tiên được quản lý qua Decap CMS."
---

Nội dung chính của bài viết. Bạn có thể viết Markdown tùy ý.
